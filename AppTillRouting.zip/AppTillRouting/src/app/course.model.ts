export class Course{
    constructor(public name:string="",
    public price:number=0,
    public duration:number=0,
    public quantity:number=0,
    public imageUrl:string="",
    public rating:number=0){

    }
}