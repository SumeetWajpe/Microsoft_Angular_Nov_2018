import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-simple-course',
  templateUrl: './simple-course.component.html',
  styleUrls: ['./simple-course.component.css'],
  providers:[CourseService]
})
export class SimpleCourseComponent implements OnInit {

  courses:string[]=[];
  courseToBeadded:string="";
  constructor(public servObj:CourseService) { 
    this.courses = (servObj.listOfCourses);
  }

  HandleClick(){
    this.servObj.addNewCourse(this.courseToBeadded)
  }

  ngOnInit() {
  }

}
