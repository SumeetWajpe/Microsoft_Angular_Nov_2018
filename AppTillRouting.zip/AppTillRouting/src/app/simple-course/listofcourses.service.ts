import { Course } from "../course.model";
import {HttpClient} from '@angular/common/http';
import { Injectable } from "@angular/core";
import { Observable } from "rxjs/Observable";

@Injectable() // to inject this service with HttpClient Service !
export class ListOfCoursesService{
    
    allCourses:Course[]=[];
    constructor(public httpServObj:HttpClient) {      
        
    }
    
    // getAllCourses():Observable<Course[]>{
    //     // make an AJAXified Request !
    //    return  this.httpServObj.get<Course[]>('https://api.myjson.com/bins/sqo9a');
            
    // }

    getAllCourses(){
        // make an AJAXified Request !
       return  this.httpServObj.get<Course[]>('https://api.myjson.com/bins/sqo9a').toPromise();
            
    }

    addNewCourse(aNewCourse:Course){
        this.allCourses.push(aNewCourse);
    }
}