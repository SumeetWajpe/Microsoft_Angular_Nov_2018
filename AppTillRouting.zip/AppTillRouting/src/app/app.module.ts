import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import CourseComponent from './course.component';
import { DurationPipe } from './duration.pipe';
import ListOfCoursesComponent from './listofcourses.component';
import {FormsModule} from '@angular/forms';
import { SimpleCourseComponent } from './simple-course/simple-course.component';
import { CourseService } from './course.service';
import { ListOfCoursesService } from './simple-course/listofcourses.service';

import {HttpClientModule} from '@angular/common/http';
import {Routes,RouterModule} from '@angular/router';
import { PostsComponentComponent } from './posts-component/posts-component.component';
import { PostsService } from './posts-service.service';

var routes:Routes = [
  {path:'',component:ListOfCoursesComponent},
  {path:'simplecourses',component:SimpleCourseComponent},
  {path:'posts',component:PostsComponentComponent},

];


@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    DurationPipe,
    ListOfCoursesComponent,
    SimpleCourseComponent,
    PostsComponentComponent
  ],

  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,RouterModule.forRoot(routes)
  ],
  providers:[ListOfCoursesService,PostsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
