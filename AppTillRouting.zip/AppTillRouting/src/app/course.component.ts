import {Component, Input} from '@angular/core';
import { Course } from './course.model';
@Component({
    selector:'course',
    templateUrl:`./course.template.html`,
    styleUrls:['./course.component.css']
})
export default class CourseComponent{
    @Input()    coursedetails:Course=new Course("Angular",2000);
}