import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name:'timeDuration'
})
export class DurationPipe implements PipeTransform
{
        transform(inputValue:number,args:string){
                return inputValue + " " + args;
        }
}