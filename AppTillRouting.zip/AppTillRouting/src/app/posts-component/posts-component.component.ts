import { Component, OnInit } from '@angular/core';
import { PostsService } from '../posts-service.service';

@Component({
  selector: 'app-posts-component',
  templateUrl: './posts-component.component.html',
  styleUrls: ['./posts-component.component.css']
})
export class PostsComponentComponent implements OnInit {

  posts:any = [];
  constructor(public postServObj:PostsService) {  }

  ngOnInit() {
      this.postServObj.getAllPosts().subscribe(
        (response) => {
          this.posts = response;
        }
      )
  }

}
