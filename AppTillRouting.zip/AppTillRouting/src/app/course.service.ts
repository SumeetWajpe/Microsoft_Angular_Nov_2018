export class CourseService {

    listOfCourses: string[] = ['React', "Node", "Angular"];

    getCourses(): string[] {
        return this.listOfCourses;
    }

    addNewCourse(aNewCourse: string): void {
        this.listOfCourses.push(aNewCourse);
    }

}