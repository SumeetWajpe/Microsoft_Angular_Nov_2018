import { Injectable } from '@angular/core';
import {HttpClient}  from '@angular/common/http'
@Injectable()
export class PostsService {
  constructor(public servObj:HttpClient) {
   }

   getAllPosts(){
     return this.servObj.get('https://jsonplaceholder.typicode.com/posts')
   }

}
