import {Component, Input} from '@angular/core';
import { Course } from './course.model';
import { ListOfCoursesService } from './simple-course/listofcourses.service';

@Component({
    selector:'list-of-courses',
    templateUrl:`./listofcourses.component.html`,
    styles:[`
    
    input.ng-pristine.ng-invalid{
        background-color:lightyellow;
    }
    input.ng-dirty.ng-valid{
        background-color:lightgreen;
    }
    input.ng-dirty.ng-invalid{
        border:2px solid red;
    }   
    
    `]
})
export default class ListOfCoursesComponent{
    courses:Course[]=[];
newCourse:Course = new Course();

constructor(public courseServObj:ListOfCoursesService) {
  
    // Using Observables !
    // this.courseServObj.getAllCourses().subscribe(
    //     (response)=>{
    //         console.log(response);
    //             this.courses = response;  
    //     }
    // );

    // Using Promises
    let returnedPromise = this.courseServObj.getAllCourses();
    returnedPromise.then(
        (response)=>{
            this.courses = response;
            this.courseServObj.allCourses = response;
        },
        (err)=>{console.log(err)}
        ); // eof then !

}

AddNewCourse(f){
    // add to the collection !

        if(f.valid){
            if(this.newCourse.imageUrl == ""){
                this.newCourse.imageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/1024px-No_image_available.svg.png";
            }
            this.courseServObj.addNewCourse(this.newCourse);
            this.newCourse = new Course();
            f.reset();
        }


   
}

}