import {Component, Input} from '@angular/core';
import { Course } from './course.model';
@Component({
    selector:'list-of-courses',
    templateUrl:`./listofcourses.component.html`
})
export default class ListOfCoursesComponent{
    courses:Course[]=[new Course("Node",3000,3,30,"https://cdn-images-1.medium.com/max/1200/1*9bVaonlM0iP8mSu45GzIeg.png",4.358),
    new Course("Vue",7000,2,0,"https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Vue.js_Logo_2.svg/1200px-Vue.js_Logo_2.svg.png",3),
   new Course("React",6000,4,100,"https://cdn-images-1.medium.com/max/1600/1*xkvjbVykgUr8I3nZntymsg.png",5),
   new Course("Backbone",5000,4,0,"http://backbonejs.org/docs/images/backbone.png",4),
   new Course("Angular",6000,4,40,"https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/250px-Angular_full_color_logo.svg.png",3)

];
newCourse:Course = new Course();

AddNewCourse(){
    // add to the collection !
    this.courses.push(this.newCourse);
    this.newCourse = new Course();
}

}