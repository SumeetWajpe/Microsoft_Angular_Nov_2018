import { Component } from '@angular/core';
import { Course } from './course.model';

@Component({
  selector: 'app-root',
//   template:`
// <!--
//   <img src={{ImageUrl}} height="400px" width="400px" />
//   <img [src]="ImageUrl" height="400px" width="400px" /> -->


//   <course [coursedetails]="course1"></course>
//   <course [coursedetails]="course2"></course>
//   <course [coursedetails]="course3"></course>
//   <course></course>
//   `,
  templateUrl:`./app.component.html`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Online Tuts';
  ImageUrl :string = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/250px-Angular_full_color_logo.svg.png" ;
   isVisible:boolean = true;  

  ChangeTitle(){
    // update model !
    this.title = "Online Tutorials !";
  }

  ChangeTitleOnTextChange(e:any){
    // change the title !
    this.title = (e.target.value)
  }

}
